# Forex Trade Technology — Global Branding Release (2026-11-01)

## Current live WordPress status

- Site: https://omar.akogs-fashion.com/
- Active theme: Forex Trade Technology **v0.1.7** (as verified through authenticated WordPress read-only integration).
- ChatGPT Gateway v1.0.0 and MCP Adapter 0.7.1 are active.
- The previously approved footer correction **was applied and verified**; gateway backup `af87bc3dee42d1824146d1c55ecb09ec`.
- **This new branding module has NOT been installed on the live site.**

## Recommended safe route: Install the companion plugin FIRST

1. Back up the site's files and database, especially the active theme, `wp_template`, `wp_template_part`, `wp_global_styles`, and WordPress options.
2. In WordPress Admin, go to Plugins → Add New → Upload Plugin.
3. Install **FTT-Global-Brand-Controls-v1.1.0.zip** and activate.
4. Open **Appearance → Forex Global Settings**. You can change these controls without entering any page's Edit screen:
   - Website title and description/tagline.
   - Header logo (linked to WordPress Site Logo option, used by Gutenberg's Site Logo block).
   - Header logo width.
   - Separate footer logo and width. **If no footer logo is selected, the plugin bundles a transparent light-on-dark logo.**
   - Site icon/favicon (square image at least 512 × 512 pixels).
   - Footer body, heading, link, hover and background colors.
   - Hide duplicate text-based footer brand (on by default).
   - Extra room between footer social icons and floating back-to-top button.
   - Footer description override (optional), WhatsApp and Telegram channel URLs.
5. Save once. Check desktop and mobile footer on home and inner pages; clear any page/cache plugin/CDN cache.
6. If it fails, deactivate the companion plugin to remove the new front-end customizations while retaining the existing theme and templates. Previous gateway template changes remain separately reversible using the gateway backup.

**Site Editor remains available** at Appearance → Editor for template layout and per-block edits. Global settings are intentionally separate; header logo changes in the new settings affect native Site Logo blocks via core WordPress storage.

## Complete theme ZIP — staging upgrade candidate

File: **Forex-Trade-Technology-FSE-Theme-v0.1.8-Global-Branding.zip**.

This is a complete, installable theme based on the tested GitHub PR #23 **v0.1.3** theme artifact with the new global-branding module incorporated, versioned **0.1.8** and including 13 content JSON datasets, FSE templates, blocks and original design styles.

**CRITICAL:** Your current live WordPress theme is **v0.1.7**, and the current installed theme's exact source ZIP is not accessible with the connected WordPress integration. v0.1.7 may contain changes that are not in the GitHub PR #23 v0.1.3 package. Therefore do NOT install v0.1.8 over production without exporting the exact v0.1.7 theme and diffing, plus staging pixel parity and runtime checks. The plugin-first method above avoids that risk.

The theme ZIP includes the same global branding functionality. If the companion plugin is also active, it supplies the shared module, and the theme skips duplicate registration. The companion plugin is not required for a fresh standalone theme install.

## Logo asset

`FTT-footer-transparent.png` is a high-resolution transparent-background **reconstruction** of the logo visible in the supplied screenshot, with the text adjusted to be readable on the dark footer. It is not an exact pixel-extracted original from WordPress Media Library. To preserve your exact artwork, upload an official transparent PNG using the Global Settings Footer Logo picker; no code edits are required.

## Test and release gates

- PHP syntax lint for all PHP in the theme and the plugin: passed.
- JavaScript `node --check` for admin and existing theme scripts: passed.
- PHP unit-style smoke tests for footer HTML filtering, description override, CSS variables, default transparent logo: passed.
- ZIP integrity, expected directory structure, 13 JSON content pages, block definitions, essential FSE parts and 8-bit alpha transparency: passed.
- Native WordPress functional test of the NEW branding module on this exact site: **not run** (plugin not installed).
- Full visual acceptance: **not run**. Test mobile and desktop, navigation, contact button contrast, social icon overlap, native logo output, FSE Site Editor save/reload and responsiveness.

## Change safety

Never paste WordPress passwords or Application Passwords into ChatGPT messages. The plugin doesn't use an API key and doesn't expose new unauthenticated write APIs. The admin page requires `manage_options` plus a WordPress CSRF nonce. The gateway remains separately responsible for owner-approved AI writes and rollback.
