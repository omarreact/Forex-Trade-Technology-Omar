FOREX TRADE TECHNOLOGY — WORDPRESS SHARE PACKAGE
Prepared for manual sharing via WhatsApp.

CONTENTS
1. Forex-Trade-Technology-FSE-Theme-v0.1.8-Global-Branding.zip
   WordPress FSE theme ZIP. NOTE: Built from GitHub v0.1.3 candidate, NOT from the exact active live v0.1.7 theme. Do not overwrite production without a staging test and backup.
2. FTT-Global-Brand-Controls-v1.1.1-Footer-Aligned.zip
   Recommended plugin for the currently active WordPress v0.1.7 theme: transparent footer logo, alignment, globally editable brand settings.
3. FTT-footer-transparent.png
   Transparent recreated logo for the footer (not exact pixel-identical original artwork).
4. FTT-Global-Branding-Installation-Guide.md
   Installation guidance.

SAFE INSTALLATION
- Back up files and database.
- For the live site, install the GLOBAL BRAND CONTROLS PLUGIN under Plugins > Add Plugin > Upload Plugin.
- Activate, then check Appearance > Forex Global Settings.
- Avoid directly installing/replacing the full FSE theme on production until staging has confirmed visual parity with the existing active v0.1.7 build.
- Check desktop and mobile site appearance and purge any cache.
- To roll back plugin effects, deactivate the plugin.

SEND VIA WHATSAPP
Open the chat with the intended recipient in your own WhatsApp account, attach this ZIP (or the component ZIPs) using Document, then send. This package itself has not been sent automatically.
