<?php
/**
 * Title: Forex Brokerage Technology Projects
 * Slug: forex-trade-technology/content-portfolio
 * Categories: pages, featured
 * Description: Fully editable page layout based on the supplied Google Doc.
 */
?>
<!-- wp:group {"className":"ftt-redesign ftt-rd-intro ftt-rd-intro--portfolio bs-section","tagName":"section","anchor":"top"} -->
<section id="top" class="wp-block-group ftt-redesign ftt-rd-intro ftt-rd-intro--portfolio bs-section">
<!-- wp:group {"className":"ftt-rd-lead-grid"} -->
<div class="wp-block-group ftt-rd-lead-grid">
<!-- wp:group {"className":"ftt-rd-lead-col"} -->
<div class="wp-block-group ftt-rd-lead-col">
<!-- wp:paragraph {"className":"ftt-rd-eyebrow"} -->
<p class="ftt-rd-eyebrow">FOREX TRADE TECHNOLOGY</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"ftt-rd-title"} -->
<h1 class="wp-block-heading ftt-rd-title">Forex Brokerage Technology Projects</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"ftt-rd-deck"} -->
<p class="ftt-rd-deck">Discretion is normal in this industry. Many brokers prefer not to name their technology partners, and we respect that. So instead of logos, our case studies focus on what matters to you as a prospective client: the problem, the technology involved and how we approached it.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"ftt-rd-lead"} -->
<p class="ftt-rd-lead">The forex brokerage technology projects below show the range of work we take on, from complete launches to fixing one stubborn part of an existing setup.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-lead-toc"} -->
<div class="wp-block-group ftt-rd-lead-toc">
<!-- wp:paragraph {"className":"ftt-rd-side-label"} -->
<p class="ftt-rd-side-label">SELECTED PROJECTS</p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"ftt-rd-chapter-links"} -->
<ul class="wp-block-list ftt-rd-chapter-links"><!-- wp:list-item -->
<li><a href="#international-forex-brokerage-mt5-white-label-crm-integration">International Forex Brokerage: MT5 White Label &amp; CRM Integration</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#regional-broker-crm-migration">Regional Broker: CRM Migration</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#multi-asset-broker-liquidity-aggregation">Multi-Asset Broker: Liquidity Aggregation</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#prop-trading-firm-challenge-automation-crm">Prop Trading Firm: Challenge Automation &amp; CRM</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#existing-mt4-broker-hosting-migration-disaster-recovery">Existing MT4 Broker: Hosting Migration &amp; Disaster Recovery</a></li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cards","tagName":"section","anchor":"international-forex-brokerage-mt5-white-label-crm-integration"} -->
<section id="international-forex-brokerage-mt5-white-label-crm-integration" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cards">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">01 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">International Forex Brokerage: MT5 White Label &amp; CRM Integration</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Project Overview</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">A newly formed brokerage preparing to serve retail clients across several regions.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Client Requirement</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">A branded MT5 environment, a forex CRM with client portal, payment integration and KYC onboarding, all ready for launch.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Business Challenge</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The founders had a clear business plan and a fixed launch window but no in-house technical team. They needed one partner to coordinate everything.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Technology Required</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT5 white label, trading server hosting, liquidity bridge, forex CRM, client portal, payment service provider integration and KYC integration.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Our Solution</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We designed the full stack around their account structure and target regions, then delivered it as one coordinated project with a single roadmap.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">06</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Implementation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Hosting and platform configuration came first, followed by liquidity connectivity, then the CRM, payments and KYC. The final stage was repeated end-to-end testing of the full client journey.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">07</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integrations</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT5, liquidity bridge, CRM, client portal, two payment providers and a verification provider.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">08</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Result</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The brokerage launched with every system connected from day one. Their operations team runs onboarding, funding and account management from one CRM instead of several separate tools.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted","tagName":"section","anchor":"regional-broker-crm-migration"} -->
<section id="regional-broker-crm-migration" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">02 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Regional Broker: CRM Migration</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Project Overview</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">An established broker whose CRM no longer kept up with its client base or partner network.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Client Requirement</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Move to a CRM with proper MT5 integration, automated IB commissions and better reporting.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Business Challenge</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Years of client records, documents and transaction history had to move across without interrupting live operations or confusing clients.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Technology Required</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Forex CRM, MT5 integration, data migration, IB management and client portal.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Our Solution</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We mapped the existing data structure, cleaned inconsistent records and set up the new CRM to run in parallel with the old one during the transition.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">06</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Implementation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Migration ran in phases. Each phase was checked against the old system before moving on, and the final switchover was scheduled outside busy trading hours.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">07</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integrations</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT5, payment providers, KYC provider and multi-level IB commission plans.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">08</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Result</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Operations moved to the new CRM with client history intact. IB commissions now calculate automatically, removing a monthly spreadsheet process.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cards","tagName":"section","anchor":"multi-asset-broker-liquidity-aggregation"} -->
<section id="multi-asset-broker-liquidity-aggregation" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cards">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">03 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Multi-Asset Broker: Liquidity Aggregation</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Project Overview</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">A broker expanding beyond forex into indices and commodities.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Client Requirement</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Connect additional liquidity providers, aggregate pricing and add backup routing.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Business Challenge</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Each provider used different symbol names, contract sizes and price digits, and the broker had experienced pricing issues with a previous integration.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Technology Required</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Liquidity bridge, aggregation, symbol mapping, FIX API connectivity and monitoring.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Our Solution</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We rebuilt the symbol mapping from scratch, documented every instrument and configured routing rules to match the broker&#039;s hybrid execution model.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">06</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Implementation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Each provider was connected and tested on its own, then together. Price feeds were validated against provider data and failover was tested deliberately.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">07</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integrations</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT5, liquidity bridge, FIX sessions and several liquidity providers.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">08</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Result</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The broker expanded its instrument range with a documented, tested mapping and a fallback path if any single provider connection drops.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted","tagName":"section","anchor":"prop-trading-firm-challenge-automation-crm"} -->
<section id="prop-trading-firm-challenge-automation-crm" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">04 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Prop Trading Firm: Challenge Automation &amp; CRM</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Project Overview</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">A growing prop firm whose team was checking rules and creating accounts largely by hand.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Client Requirement</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Automated account creation, rule monitoring, phase progression and payout workflows.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Business Challenge</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Rising trader numbers meant manual processes were creating delays, inconsistent rule decisions and support complaints.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Technology Required</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Prop firm CRM, platform API integration, trader dashboard, payment integration and affiliate tracking.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Our Solution</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We configured challenge types and rules in the CRM and connected it to the trading platform so accounts are created, monitored and updated automatically.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">06</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Implementation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Every stage of the trader lifecycle was tested, including breaches, passes, resets and payout reviews, before the old process was retired.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">07</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integrations</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Trading platform API, checkout and payment providers, KYC provider and affiliate system.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">08</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Result</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Rules are now applied consistently with a clear record behind each decision, and traders can see their own progress, which reduced support questions.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cards","tagName":"section","anchor":"existing-mt4-broker-hosting-migration-disaster-recovery"} -->
<section id="existing-mt4-broker-hosting-migration-disaster-recovery" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cards">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">05 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Existing MT4 Broker: Hosting Migration &amp; Disaster Recovery</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Project Overview</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">An MT4 broker experiencing instability with its existing hosting.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Client Requirement</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Move to more reliable infrastructure with proper monitoring and a recovery plan.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Business Challenge</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The broker had no tested backups and no documented plan for a server failure, and clients had noticed disruption during busy sessions.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Technology Required</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT4 server hosting, monitoring, backup systems and disaster recovery planning.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Our Solution</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We planned new infrastructure closer to the broker&#039;s liquidity providers, with monitoring, scheduled backups and a standby environment.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">06</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Implementation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The migration was rehearsed in advance and carried out during a quiet period. Backup restores were tested after the move.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">07</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integrations</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT4 server, liquidity bridge and CRM.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">08</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Result</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The broker now has monitored infrastructure, verified backups and a documented recovery procedure their team understands.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted","tagName":"section","anchor":"introducing-broker-grey-label-launch"} -->
<section id="introducing-broker-grey-label-launch" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">06 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Introducing Broker: Grey Label Launch</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Project Overview</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">An introducing broker with an established client network ready to launch its own brand.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Client Requirement</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">A lean, branded brokerage setup with a CRM and client portal.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Business Challenge</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">A limited budget and the need to keep existing clients engaged during the transition.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Technology Required</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT5 grey label, forex CRM, client portal, broker website and payment integration.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Our Solution</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We structured a grey label setup and connected a CRM and portal, with the integrations planned so a move to white label later would be straightforward.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">06</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Implementation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Branding and account types were configured, the website and portal built, and the full client journey tested before launch.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">07</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integrations</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">MT5 grey label, CRM, client portal and payment provider.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">08</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Result</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">The business moved from referral income to its own branded brokerage, with a clear upgrade path for when volumes justify it.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--article","tagName":"section","anchor":"have-a-project-in-mind"} -->
<section id="have-a-project-in-mind" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--article">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">07 / PORTFOLIO</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Have a Project in Mind?</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Every brokerage brings its own mix of goals, systems and constraints. Tell us what you&#039;re working on, and we&#039;ll explain how we&#039;d approach it.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
