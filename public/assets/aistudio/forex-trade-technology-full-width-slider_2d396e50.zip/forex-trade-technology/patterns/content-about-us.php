<?php
/**
 * Title: Technology for the Modern Forex Brokerage
 * Slug: forex-trade-technology/content-about-us
 * Categories: pages, featured
 * Description: Fully editable page layout based on the supplied Google Doc.
 */
?>
<!-- wp:group {"className":"ftt-redesign ftt-rd-intro ftt-rd-intro--about bs-section","tagName":"section","anchor":"top"} -->
<section id="top" class="wp-block-group ftt-redesign ftt-rd-intro ftt-rd-intro--about bs-section">
<!-- wp:group {"className":"ftt-rd-lead-grid"} -->
<div class="wp-block-group ftt-rd-lead-grid">
<!-- wp:group {"className":"ftt-rd-lead-col"} -->
<div class="wp-block-group ftt-rd-lead-col">
<!-- wp:paragraph {"className":"ftt-rd-eyebrow"} -->
<p class="ftt-rd-eyebrow">FOREX TRADE TECHNOLOGY</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"ftt-rd-title"} -->
<h1 class="wp-block-heading ftt-rd-title">Technology for the Modern Forex Brokerage</h1>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-side-visual"} -->
<div class="wp-block-group ftt-rd-side-visual">
<!-- wp:image {"sizeSlug":"full","className":"ftt-rd-diagram"} -->
<figure class="wp-block-image size-full ftt-rd-diagram"><img loading="lazy" decoding="async" src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/illustrations/about-us.svg" alt="Technology for the Modern Forex Brokerage technology diagram" width="960" height="720"/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--article","tagName":"section","anchor":"who-we-are"} -->
<section id="who-we-are" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--article">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">01 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Who We Are</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We&#039;re a forex technology company that builds and connects the systems brokerages run on. Trading platforms, CRM, liquidity connectivity, hosting, payments, onboarding tools and the integrations between them.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We started with a simple observation. Most brokerages don&#039;t struggle because they lack software. They struggle because their software doesn&#039;t work together. A platform from one vendor, a CRM from another, payments bolted on later and nobody responsible for the gaps in between. We set out to be the team that takes responsibility for those gaps.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">It&#039;s worth being clear about what we&#039;re not. We&#039;re not a broker. We don&#039;t offer trading services, investment advice or liquidity, and we don&#039;t hold or manage client funds. Our work is technology, and we keep it that way.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted","tagName":"section","anchor":"our-expertise"} -->
<section id="our-expertise" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">02 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Our Expertise</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Our team works across the full brokerage stack. That includes MT5 and MT4 configuration and administration, CRM development and integration, liquidity bridges, FIX API connectivity and aggregation, trading server hosting and infrastructure, payment and KYC/AML integrations, Manager API development, mobile and web trading, prop firm systems and PAMM and MAM solutions.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">That range matters more than any single skill. When a client&#039;s deposit doesn&#039;t show up in their trading balance, the cause could sit in the payment provider, the webhook handling, the CRM workflow or the platform integration. A team that understands every layer can find the real problem quickly instead of passing it along.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cards","tagName":"section","anchor":"our-technology-approach"} -->
<section id="our-technology-approach" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cards">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">03 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Our Technology Approach</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Plan the Whole System</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Even when a broker only needs one piece from us, we look at how it fits with everything else. A hosting decision affects liquidity. A CRM decision affects onboarding. Payment choices affect reporting. Planning with the full picture avoids expensive rework later.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Prefer Reliable Over Flashy</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Well-configured, well-documented systems that your team can understand and work with. Clever features matter less than a setup that behaves predictably on a busy trading day.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Test What Could Go Wrong</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Failed payments, rejected documents, dropped connections and execution rejections all happen in real operations. We test for them before launch, not after.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Build for the Next Stage</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Your setup should handle more clients, new products and new regions without a rebuild. We design with that growth in mind from the start.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted","tagName":"section","anchor":"brokerage-solutions"} -->
<section id="brokerage-solutions" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">04 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Brokerage Solutions</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Our work covers MT5 and MT4 white label and grey label setups, forex white label solutions, turnkey brokerage launches, forex CRM, liquidity and connectivity, broker hosting, broker websites, mobile trading apps, web trading, Manager API integration, prop firm CRM and API, PAMM and MAM, and payment gateway integration.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Some clients take the full stack. Others come to us for one specific problem. Both are welcome.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--timeline","tagName":"section","anchor":"our-development-process"} -->
<section id="our-development-process" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--timeline">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">05 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Our Development Process</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Every project follows the same path, scaled to its size.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Consultation</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We learn how your business works, what you&#039;re trying to achieve and what you already have.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Solution Design</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We recommend the platform model, systems and integrations that fit, and show you how they&#039;ll connect before anything is built.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Integration and Testing</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We configure, connect and test the full setup, including full client journeys and failure scenarios.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Launch and Support</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We go live with you, monitor closely through the early weeks and stay on as your technology partner.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted","tagName":"section","anchor":"support"} -->
<section id="support" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">06 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Support</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">For us, launch is where the long-term relationship begins. After go-live, you get technical support from the team that built your setup, so you&#039;re never explaining your configuration to strangers. We handle monitoring, configuration changes, troubleshooting, upgrades and help as you add new products, providers or markets. Planned changes are scheduled with you, away from busy trading periods.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cards","tagName":"section","anchor":"industries-we-serve"} -->
<section id="industries-we-serve" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cards">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">07 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Industries We Serve</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Forex and CFD Brokers</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">New brokerages preparing to launch and established brokers improving or expanding their technology.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Prop Trading Firms</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Firms running evaluation programmes that need account automation, rule monitoring and payout workflows.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Introducing Brokers</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">IBs ready to move from referring clients to running their own branded brokerage.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Money Managers</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Traders and firms offering managed account services through PAMM and MAM.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--cards"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--cards">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">FinTech Companies</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Businesses adding trading capability to an existing financial product or platform.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted","tagName":"section","anchor":"why-work-with-us"} -->
<section id="why-work-with-us" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">08 / ABOUT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Why Work With Us</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">One Team Across the Stack</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">You don&#039;t have to coordinate between vendors who&#039;ve never spoken to each other.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Straight Answers</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">If a grey label suits you better than a white label, we&#039;ll say so. If something can&#039;t be done the way you hoped, you&#039;ll hear it early, not after you&#039;ve paid for it.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">No Inflated Promises</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We don&#039;t promise licences, guaranteed uptime, guaranteed execution or guaranteed profits, because nobody can honestly control those outcomes. We promise careful work and real support.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Clear Responsibility Boundaries</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We&#039;re upfront about what sits with us and what stays with your business, including compliance, regulatory and risk decisions.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">05</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">A Long-Term View</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We&#039;d rather build something that still works well in three years than something that just gets you through launch week.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cta","tagName":"section","anchor":"let-s-talk-about-your-brokerage"} -->
<section id="let-s-talk-about-your-brokerage" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cta">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-side"} -->
<div class="wp-block-group ftt-rd-side">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">09 / ABOUT</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Let&#039;s Talk About Your Brokerage</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Whether you&#039;re planning your first launch or fixing one part of an existing setup, we&#039;d like to hear what you&#039;re working on. Tell us where you are and where you want to go, and we&#039;ll show you how we can help.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"bs-btn-dark"} -->
<div class="wp-block-button bs-btn-dark"><a class="wp-block-button__link wp-element-button" href="/contact/#contact-form">Request a Consultation</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
