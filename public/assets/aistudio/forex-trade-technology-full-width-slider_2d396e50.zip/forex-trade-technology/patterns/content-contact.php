<?php
/**
 * Title: Let's Build Your Brokerage Technology Stack
 * Slug: forex-trade-technology/content-contact
 * Categories: pages, featured
 * Description: Fully editable page layout based on the supplied Google Doc.
 */
?>
<!-- wp:group {"className":"ftt-redesign ftt-rd-intro ftt-rd-intro--contact bs-section","tagName":"section","anchor":"top"} -->
<section id="top" class="wp-block-group ftt-redesign ftt-rd-intro ftt-rd-intro--contact bs-section">
<!-- wp:group {"className":"ftt-rd-lead-grid"} -->
<div class="wp-block-group ftt-rd-lead-grid">
<!-- wp:group {"className":"ftt-rd-lead-col"} -->
<div class="wp-block-group ftt-rd-lead-col">
<!-- wp:paragraph {"className":"ftt-rd-eyebrow"} -->
<p class="ftt-rd-eyebrow">FOREX TRADE TECHNOLOGY</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":1,"className":"ftt-rd-title"} -->
<h1 class="wp-block-heading ftt-rd-title">Let&#039;s Build Your Brokerage Technology Stack</h1>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"ftt-rd-deck"} -->
<p class="ftt-rd-deck">Whether you&#039;re sketching out a new brokerage or trying to fix one part of a setup that&#039;s already running, the first step is the same: a conversation. Tell us where you are, what you&#039;re aiming for and what&#039;s getting in the way.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"ftt-rd-lead"} -->
<p class="ftt-rd-lead">A forex broker technology consultation with our team is free and comes with no obligation. You don&#039;t need to register, and you don&#039;t need to have every answer ready. Working those out is part of what we do.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-lead-toc"} -->
<div class="wp-block-group ftt-rd-lead-toc">
<!-- wp:paragraph {"className":"ftt-rd-side-label"} -->
<p class="ftt-rd-side-label">EXPLORE</p>
<!-- /wp:paragraph -->
<!-- wp:list {"className":"ftt-rd-chapter-links"} -->
<ul class="wp-block-list ftt-rd-chapter-links"><!-- wp:list-item -->
<li><a href="#contact-form">Request a Consultation</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#what-helps-us-help-you">What Helps Us Help You</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#what-happens-next">What Happens Next</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#before-you-get-in-touch">Before You Get in Touch</a></li>
<!-- /wp:list-item -->
<!-- wp:list-item -->
<li><a href="#ready-when-you-are">Ready When You Are</a></li>
<!-- /wp:list-item -->
</ul>
<!-- /wp:list -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--form","tagName":"section","anchor":"contact-form"} -->
<section id="contact-form" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--form">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-side"} -->
<div class="wp-block-group ftt-rd-side">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">01 / CONTACT</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Request a Consultation</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"ftt-source-note"} -->
<p class="ftt-source-note">Fields marked * are required.</p>
<!-- /wp:paragraph -->
<!-- wp:shortcode -->
[ftt_roadmap_contact_form]
<!-- /wp:shortcode -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted","tagName":"section","anchor":"what-helps-us-help-you"} -->
<section id="what-helps-us-help-you" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--rail ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">02 / CONTACT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">What Helps Us Help You</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">You don&#039;t need to write an essay, but a few details make the first conversation far more useful. It helps to know your target markets and the type of clients you want to serve, which platform you use now or are considering, any systems or providers you already have in place, and roughly when you&#039;re hoping to launch or make changes.</p>
<!-- /wp:paragraph -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Please don&#039;t include passwords, account credentials or sensitive financial details in the form. We&#039;ll never ask for them at this stage.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--timeline","tagName":"section","anchor":"what-happens-next"} -->
<section id="what-happens-next" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--timeline">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">03 / CONTACT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">What Happens Next</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Review Your Details</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Someone from our team reads through what you&#039;ve shared and looks at what your business is likely to need.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Arrange a Call</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">We get back to you to set up a conversation at a time that suits you.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">We Talk It Through</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">On the call, we discuss your business model, current setup, goals and timeline. We&#039;ll ask questions, answer yours and give you an honest view of which options make sense.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--timeline"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--timeline">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">You Get a Clear Proposal</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">If it looks like a good fit, we follow up with a scoped proposal showing what we&#039;d deliver, how it would come together and a breakdown of costs.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted","tagName":"section","anchor":"before-you-get-in-touch"} -->
<section id="before-you-get-in-touch" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--matrix ftt-rd-section--tinted">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-section-head"} -->
<div class="wp-block-group ftt-rd-section-head">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">04 / CONTACT</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Before You Get in Touch</h2>
<!-- /wp:heading -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-items"} -->
<div class="wp-block-group ftt-rd-items">
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">01</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Is the consultation free?</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Yes. There&#039;s no charge and no commitment.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">02</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Do I need to know exactly what I want?</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">No. Many brokers come to us with a goal rather than a technical plan. Helping you work out the right setup is part of the consultation.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">03</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Can I contact you about just one service?</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Of course. Whether it&#039;s a CRM, liquidity connectivity, hosting or a full turnkey launch, we&#039;re happy to talk.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-item ftt-rd-item--matrix"} -->
<div class="wp-block-group ftt-rd-item ftt-rd-item--matrix">
<!-- wp:paragraph {"className":"ftt-rd-card-index"} -->
<p class="ftt-rd-card-index">04</p>
<!-- /wp:paragraph -->
<!-- wp:heading {"level":3,"className":"ftt-rd-card-title"} -->
<h3 class="wp-block-heading ftt-rd-card-title">Do you provide legal or licensing advice?</h3>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">No. We focus on technology. For regulatory matters, we recommend working with qualified legal and compliance advisors.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
<!-- wp:group {"className":"alignfull bs-section ftt-rd-section ftt-rd-section--cta","tagName":"section","anchor":"ready-when-you-are"} -->
<section id="ready-when-you-are" class="wp-block-group alignfull bs-section ftt-rd-section ftt-rd-section--cta">
<!-- wp:group {"className":"bs-container ftt-rd-section-wrap"} -->
<div class="wp-block-group bs-container ftt-rd-section-wrap">
<!-- wp:group {"className":"ftt-rd-side"} -->
<div class="wp-block-group ftt-rd-side">
<!-- wp:paragraph {"className":"ftt-rd-section-index"} -->
<p class="ftt-rd-section-index">05 / CONTACT</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
<!-- wp:group {"className":"ftt-rd-section-body"} -->
<div class="wp-block-group ftt-rd-section-body">
<!-- wp:heading {"level":2,"className":"ftt-rd-section-title"} -->
<h2 class="wp-block-heading ftt-rd-section-title">Ready When You Are</h2>
<!-- /wp:heading -->
<!-- wp:paragraph {"className":"bs-copy"} -->
<p class="bs-copy">Fill in the form above, and let&#039;s start working out the technology your brokerage needs.</p>
<!-- /wp:paragraph -->
<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button {"className":"bs-btn-dark"} -->
<div class="wp-block-button bs-btn-dark"><a class="wp-block-button__link wp-element-button" href="/contact/#contact-form">Request a Consultation</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
